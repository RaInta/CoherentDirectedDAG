#!/bin/bash
#!/usr/bin/perl5.10.1

cd /home/ra/searches/ER8/HWinj/P3/jobs/upper_limit
perl /home/ra/searches/PostCasA/Scripts/CollateUpperLimits.pl

#!/bin/bash
#!/usr/bin/perl5.10.1

cd /home/ra/searches/ER8/HWinj/P3/jobs/templ_dens
perl /home/ra/searches/PostCasA/Scripts/CollateTemplateDensities.pl

cd /home/ra/searches/ER8/HWinj/P3/jobs/comp_cost
perl /home/ra/searches/PostCasA/Scripts/MakeEstimateComputeCost_new.pl --account-group ligo.prod.s6.cw.directedisolated.coherent --account-user ra.inta

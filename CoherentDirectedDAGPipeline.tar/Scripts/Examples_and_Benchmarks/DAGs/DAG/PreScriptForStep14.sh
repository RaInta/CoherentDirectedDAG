#!/bin/bash
#!/usr/bin/perl5.10.1

perl /home/ra/searches/PostCasA/Scripts/MakeCollateSearchResults_new.pl --account-group ligo.prod.s6.cw.directedisolated.coherent --account-user ra.inta

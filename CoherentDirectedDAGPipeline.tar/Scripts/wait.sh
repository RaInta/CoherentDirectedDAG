#!/bin/bash

TIMER=$1

echo "Waiting for ${TIMER} seconds..."
sleep ${TIMER}
echo "Done."

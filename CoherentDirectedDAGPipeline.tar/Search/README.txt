This folder contains the following data files:

H1L1-combined_psd.dat astro-targets-converted.dat

which are the combined detector noise PSD and astrophysical target list, respectively.

The former is an example noise curve for O1. The latter is a rough guide as to what 
format the setup pipeline expects. This will be revised!

20160516, Ra Inta

#!/bin/bash
#!/usr/bin/perl5.10.1

cd /home/ra/searches/ER8/HWinj/P3/jobs/search
perl /home/ra/searches/PostCasA/Scripts/MakeSearchJobs_new.pl --job-hours 5 --account-group ligo.prod.s6.cw.directedisolated.coherent --account-user ra.inta 

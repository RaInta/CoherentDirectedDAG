This folder is meant to illustrate the structure and filenames of the result of running the Coherent Directed search pipeline using a DAG system.
It was the result of running a short (10.6 days) search on the CW hardware injection P3 during the pre-O1 engineering run, ER8. 
This is current as of 22 January 2016.

Contact: Ra Inta, ra.inta@ligo.org
Last modified: 20160122, R.I.

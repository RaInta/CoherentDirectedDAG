#!/bin/bash

echo "This is a test, we'll probably get rid of this step" 

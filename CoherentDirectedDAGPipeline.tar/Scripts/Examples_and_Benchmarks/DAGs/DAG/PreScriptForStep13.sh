#!/bin/bash
#!/usr/bin/perl5.10.1

cd /home/ra/searches/ER8/HWinj/P3 # Remove the following three lines if CFSv2 verbose output activated 
/home/ra/searches/PostCasA/Scripts/FixSearchLogs.sh  
cd -

perl /home/ra/searches/PostCasA/Scripts/ComputeSpectraAndVetoBands.pl

cd /home/ra/searches/ER8/HWinj/P3/jobs/full_psd
perl /home/ra/searches/PostCasA/Scripts/MakeComputeFullPSD_new.pl --account-group ligo.prod.s6.cw.directedisolated.coherent --account-user ra.inta

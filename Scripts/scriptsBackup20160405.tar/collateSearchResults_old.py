#!/usr/bin/python

#------------------------------------------------------------------------------
#           Name: collateSearchResults.py
#         Author: Ra Inta, 20151007
#  Last Modified: 20160330, R.I.
#
# This is designed to speed up the collation procedure in coherent directed
# searches. The precursor is Karl Wette's CollateSearchResults.pl script
# It reads in setuo XMLs as well as veto and search results.
# The
#------------------------------------------------------------------------------

import xml.etree.ElementTree as ET
import bz2
from intervaltree import IntervalTree
from xml.etree.ElementTree import Element, SubElement, Comment, tostring
import os
import re
from math import ceil

# For timing:
import time


start_time = time.clock()



############################################################
# 0) Read in some basic setup information
############################################################


# TODO read this from setup file---i.e. add to setup file?
JOBS_PER_SUBDIR=250 # For the moment this is hard-coded here (following the style of two other scripts in the pipeline).

# Get upper limit band from search_setup.xml
with open('search_setup.xml','r') as searchSetup:
    setup_tree = ET.parse( searchSetup )
    setup_root = setup_tree.getroot()

for search_params in setup_root.iter('search'):
    search_band = float( search_params.find('band').text )

for ul_params in setup_root.iter('upper_limit'):
    ul_band = float( ul_params.find('band').text )

num_ul_bands = ceil( search_band / ul_band )

############################################################
# 1) Take in search results and vetoes
############################################################

with bz2.BZ2File('search_bands.xml.bz2', 'rb') as searchBandsFile:
    search_tree = ET.parse( searchBandsFile )
    search_root = search_tree.getroot()


## Walk through the XML tree for job, 2F and f0; don't pick up the vetoed bands. 

search_segments = []

for jobNumber in search_root.iter('search_band'):
    search_jobNum = int( jobNumber.find('job').text )
    search_startFreq = float( jobNumber.find('freq').text )
    search_endFreq = search_startFreq + float( jobNumber.find('band').text )
    search_segments.append( (search_startFreq, search_endFreq, search_jobNum) )

## Get number of templates in each band
#for nTempl in root.iter('num_templates'):
#   num_templates.append( float( nTempl.text ) )

# Read the veto_bands XMl file and create an array of tuples containing vetoed bands

with open('veto_bands.xml', 'r') as vetoFile:
    veto_tree = ET.parse( vetoFile )
    veto_root = veto_tree.getroot()

veto_segments = []

for vetoBand in veto_root.iter('veto_band'):
    veto_startFreq = float( vetoBand.find('freq').text )
    veto_endFreq = veto_startFreq + float( vetoBand.find('band').text )
    veto_segments.append( (veto_startFreq, veto_endFreq) )




# TODO use sets?
#unvetoed_segments = [val for val in search_segments if val in set(veto_segments)]

# TODO read in upper limits bands
#with open('search_setup.xml', 'rb') as searchSetupFile:
#    setupTree = ET.parse( searchSetupFile)
#    upper_limit_bandSize = setupTree.findall



############################################################
# 2) make interval trees to compare search and veto bands
############################################################


# Create interval trees from search and veto bands
search_interval = IntervalTree.from_tuples( search_segments ) # O( n*log(n) )
veto_interval = IntervalTree.from_tuples( veto_segments )

# Remove vetoed bands from search_bands
search_interval.update( veto_interval ) # O( v*log(n) ), v is number of vetoes
search_interval.split_overlaps()  # O( n*log(n) ), best case, where
[search_interval.remove_overlap(a) for a in veto_interval] # O( (v + v_band)*log(n) ), v_band is range of vetoing (usually ~1% of band)

############################################################
# 3) Iterate over search jobs
############################################################
#
# Doing this *after* vetoing means we don't care if we didn't submit
# the search job for it etc.

# ElementTree doesn't pretty-print XML! Need to add indents.
# Stolen directly from:
# http://stackoverflow.com/questions/749796/pretty-printing-xml-in-python
def indent(elem, level=0):
    """This is a function to make the XML output pretty, with the right level
    of indentation"""
    i = "\n" + level*"  "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + "  "
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elem in elem:
            indent(elem, level+1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i

ifo_v_jobs = ''  # Initialise the ifo-vetoed jobs list
prevJobNum = -1  # This keeps track of the previous job number

for searchBand in sorted( search_interval ):
    # TODO Group all same jobs into this loop
    jobNum = searchBand[2]
    if jobNum > prevJobNum:    # Initialise only if we've moved to a new job number
        IFOvetoed = 0
        max2F = 0
        prevMax2F = 0
        loudestLine = ''
        numTemplates = ''
        subDir = "jobs/search/" + str( int( jobNum )/JOBS_PER_SUBDIR )
    # check job has been submitted
    if os.path.isfile( subDir + "/search.sub." + str( jobNum ) ):
        print "Job " + str( jobNum ) + " not submitted"
        break
    # check job files are all present
    for logFileName in ("/condor.out.", "/search.log.", "/search_results.txt.", "/search_histogram.txt.", "/condor.err."):
        logFileName = subDir + logFileName + str( jobNum )
        if not os.path.isfile( logFileName ):
            print "Search file " + logFileName + " does not exist!"
            break
    # check error files are empty
    print(logFileName)
    if os.path.getsize( logFileName ) > 0:
        print "Condor error file " + logFileName + " is not empty!"
        break
    # check search.log.$job, check for number of templates and last line
    with open( subDir + "/search.log." + str( jobNum ), 'r' ) as logFile:
        #logFile.seek(-100,2) # Skip right to 100B before the end of the file; only do this for large files
        lastLine = False
        for eachLine in logFile:
            if re.match( "^\[debug\]: Counting spindown lattice templates \.\.\.", eachLine):
                singleLine = eachLine.split()
                numTemplates = singleLine[-1]
            if re.match("^\[debug\]: Freeing Doppler grid \.\.\. done", eachLine):
                lastLine = True
        if not lastLine:
            print("No last line of search.log." + str( jobNum ) )
        if not numTemplates:
            print( "No number of templates in search.log." + str( jobNum ) )

    # check last line of search_results.txt.$job and search_histogram.txt.$job
    for jobFileSpecifier in ("histogram", "results"):
        jobFileName = subDir + "/search_" + jobFileSpecifier + ".txt." + str( jobNum )
        lastLine = False
        with open(jobFileName,"r") as jobFile:
            # Go to end of the file, check last line
            jobFile.seek(-30,2)
            for line in jobFile:
                if re.match( "%DONE$", line):
                    lastLine = True
            if not lastLine:
                print("No last line of " + jobFileName )
                break
    # If last line(s), then trawl through search_results.txt.$job
    jobFileName = subDir + "/search_results.txt." + str( jobNum )
    print("Filename is: " + jobFileName)
    with open(jobFileName,"r") as jobFile:
        for line in jobFile:
            eachLine = line.split()
            if not (eachLine[0][0] == "%"):
                twoF = eachLine[6]
                # Check if template is IFO vetoed
                if (eachLine[8] >= twoF or eachLine[9] >= twoF ):
                    IFOvetoed += 1
                elif searchBand[0] <= float( eachLine[0] ) <= searchBand[1]:
                    if twoF > max2F:
                        max2F = twoF
                        loudestLine = eachLine

           # TODO may need to flush jobFile (uncomment next line)
           # jobFile.flush()
    max2F = max( max2F, prevMax2F )
    if jobNum > prevJobNum:    # Wait until the end to print to file 
       # Add to search_bands.xml.bz2 file
       # Spit the dummy if IFOvetoed >= 0.05*numTemplates:
       if float( IFOvetoed ) >= 0.05*float( numTemplates ):
          IFOvetoed = 0
          max2F = 0
          loudestLine = ''
          # reset loudestLine and max2F, open and add searchBand
          # limits to veto_bands.xml
          # Also append to ifo_v_jobs.txt counter
          # And then write to ifo_v_jobs.txt file
          # ifo_v_jobs.append( str( jobNum ) + "\n" )
       print("Job number: " + str( jobNum ) )
       print("Previous job number: " + str( prevJobNum ) )
       print(subDir)
       print("Max 2F: " + str( max2F) )
       print("IFO veto: " + str(IFOvetoed) )
       if loudestLine:
           for searchJobElement in search_root.iter('job'):
               if searchJobElement.text == str( jobNum ):
                   # TODO change this so that the SubElement is attached to
                   # the respective search_band tag
                   loudestEl = SubElement( searchJobElement,"loudest_nonvetoed_template")
                   indent(loudestEl, 2)
                   columnIdx = ["freq", "alpha", "delta", "f1dot", "f2dot", "f3dot", "twoF", "log10BSGL", "twoF_H1", "twoF_L1"]
                   for Idx in range( len(columnIdx )):
                       loudIdx = SubElement( loudestEl, columnIdx[Idx])
                       loudIdx.text = loudestLine[Idx]
                       indent(loudIdx, 3)   # loudest template values are level 3
    prevJobNum = jobNum


indent(search_root)
search_bands_xml = ET.ElementTree(search_root)
search_bands_xml.write("search_bands_py.xml", xml_declaration=True, encoding='UTF-8' )

if len(ifo_v_jobs):   # Append ifo vetoed jobs to vetoed bands file (if they exist)
    veto_bands_xml = ET.ElementTree(veto_root)
    veto_bands_xml.write("veto_bands2.xml", xml_declaration=True, encoding='UTF-8' )

with open("ifo_v_jobs.txt",'a') as ifoJobsFile:   # Write ifo_v_jobs.txt file (will overwrite existing!)
    ifoJobsFile.write(ifo_v_jobs)


# TODO make upper limits
#upper_limit_bands = ET.ElementTree( upper_limit_root )
#upper_limit_bands.write("upper_limit_bands2.xml")


############################################################
#3) Iterate over jobs, open results file and apply vetoing
############################################################

# The following was inspired by the following StackOverflow post:
# http://stackoverflow.com/questions/8009882/how-to-read-large-file-line-by-line-in-python
# "The with statement handles opening and closing the file, including if an
# exception is raised in the inner block. The for line in f treats the
# file object f as an iterable, which automatically uses buffered IO and
#memory management so you don't have to worry about large files."
#for jobNumber in range( len(search_segments) ):
#    maxTwoF =
#    with open( "search_results.txt." + str(jobNumber) ) as f:
#        for line in f:
#            <do something with line>

## if the above doesn't work, try using fileinput library:
#import fileinput
#
#for line in fileinput.input(['myfile']):
#    do_something(line)
# It doesn't keep lines in memory after they've been read...


    # skip event processing if job is IFO vetoed
    # skip event processing if whole job is fscan vetoed
    # open search_results.txt.$job
    # parse the result line
    # get the band covered by the template
    # check fscan veto
    # count nonvetoed recorded candidates in search job
    # record the loudest non-vetoed template for search and upper limit bands
    # count if all candidates were completely vetoed
    # see if IFO veto kills whole job
    # progress update
# print any failed jobs

############################################################
#4) Create upper limit bands
############################################################


############################################################
#5) Output results
############################################################


# write search and upper limit bands
# write IFO vetoed jobs file
# Merge IFO-vetoed bands with previous veto bands
    # Construct list of f-vetoed bands that overlap the i-vetoed band
    # If no overlap, just add the search band to the veto bands
    # If IFO-vetoed band goes lower than lowest F_vetoed band...
    # If I-vetoed band goes higher than highest F-vetoed band...
    # Else stretch lowest F-vetoed band to cover all overlapping ones
    # Delete all frequency bands but lowest.
# Merge consecutive veto bands
# Rewrite veto bands database


end_time = time.clock()
print("Time taken to run (new version): " + str( end_time - start_time ) + " sec")

#------------------------------------------------------------------------------
#   End of collateSearchResults.py
#------------------------------------------------------------------------------

#!/bin/bash

pip install --user intervaltree

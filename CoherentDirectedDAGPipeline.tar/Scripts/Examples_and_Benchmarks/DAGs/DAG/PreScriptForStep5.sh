#!/bin/bash
#!/usr/bin/perl5.10.1

#rm -f /home/ra/searches/ER8/HWinj/P3/sft_database.xml.bz2 && ligo_data_find --observatory H --type '1_H1_1800SFT_allS6VSR2VSR3' --gps-start-time '954403520' --gps-end-time '971619922' --match localhost | sed 's/\.gwf$/\.sft/' | grep ldr | /home/ra/searches/PostCasA/Scripts/AddSFTsToDatabase.pl && ligo_data_find --observatory L --type '1_L1_1800SFT_allS6VSR2VSR3' --gps-start-time '954403520' --gps-end-time '971619922' --match localhost | sed 's/\.gwf$/\.sft/' | grep ldr | /home/ra/searches/PostCasA/Scripts/AddSFTsToDatabase.pl

#rm -f /home/ra/searches/ER8/HWinj/P3/sft_database.xml.bz2 && gw_data_find --observatory H --type '1_H1_1800SFT_allS6VSR2VSR3' --gps-start-time '954403520' --gps-end-time '971619922' --match localhost | grep ldr | /home/ra/searches/PostCasA/Scripts/AddSFTsToDatabase.pl && gw_data_find --observatory L --type '1_L1_1800SFT_allS6VSR2VSR3' --gps-start-time '954403520' --gps-end-time '971619922' --match localhost | grep ldr | /home/ra/searches/PostCasA/Scripts/AddSFTsToDatabase.pl
# This is just for ER7 :
# TODO: remove after ER7!!!
rm -f /home/ra/searches/ER8/HWinj/P3/sft_database.xml.bz2 && ls /home/ra/searches/ER7/fullER7/global/sfts/*.sft | /home/ra/searches/PostCasA/Scripts/AddSFTsToDatabase.pl

 
cd /home/ra/searches/ER8/HWinj/P3/jobs/get_sft_info
perl /home/ra/searches/PostCasA/Scripts/MakeGetSFTInfoJobs_new.pl --account-group ligo.prod.s6.cw.directedisolated.coherent --account-user ra.inta
